# Vibe Urban Hostel — Next.js

Recriação em React e Next.js do HTML fornecido. O conteúdo visual original descrevia um hostel, enquanto as tags de metadados mencionavam uma clínica de estética; o projeto usa a identidade do hostel em todas as seções.

## Executar

Requer Node.js 20 ou superior.

```bash
npm install
npm run dev
```

Acesse http://localhost:3000. Para conferir a versão de produção: `npm run build` e `npm start`.

## Personalização

- Edite `src/data/site.ts` para atualizar nome, endereço, telefone, WhatsApp, acomodações e imagens.
- Altere os textos e seções em `src/app/page.tsx` e as cores/estilos em `src/app/globals.css`.
- Os preços, o endereço e os contatos fornecidos no HTML de origem são demonstrativos. Substitua-os antes de publicar ou receber reservas.
- As fotografias vêm de URLs externas do Unsplash e exigem conexão para aparecer. Troque por imagens reais do local quando disponíveis.
- O botão de reserva abre o WhatsApp; não existe um sistema de reservas ou pagamentos integrado.

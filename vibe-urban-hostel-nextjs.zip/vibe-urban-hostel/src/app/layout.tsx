import type { Metadata } from "next";
import { site } from "@/data/site";
import "./globals.css";
export const metadata: Metadata = {
  title: `${site.name} | Hospedagem, encontros e novas histórias`,
  description: "Camas cápsula, suítes privativas e espaços para criar conexões. Conheça o Vibe Urban Hostel e consulte disponibilidade.",
  openGraph: { title: site.name, description: site.tagline, type: "website", locale: "pt_BR" },
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}

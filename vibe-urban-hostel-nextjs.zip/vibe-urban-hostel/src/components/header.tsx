"use client";
import { useState } from "react";
import { ArrowUpRight, Menu, X } from "lucide-react";
const links = [{ href: "#sobre", label: "O hostel" }, { href: "#acomodacoes", label: "Acomodações" }, { href: "#espacos", label: "Espaços" }, { href: "#contato", label: "Contato" }];
export function Header() {
  const [open, setOpen] = useState(false);
  return <header className="header"><div className="container header-inner"><a className="brand" href="#inicio" aria-label="Vibe Urban Hostel, início"><span className="brand-mark">v<span>.</span></span><span className="brand-name">VIBE URBAN<small>HOSTEL & CO-LIVING</small></span></a><nav className={open ? "nav nav-open" : "nav"} aria-label="Navegação principal">{links.map(link => <a key={link.href} href={link.href} onClick={() => setOpen(false)}>{link.label}</a>)}<a className="mobile-book" href="#contato" onClick={() => setOpen(false)}>Consultar datas <ArrowUpRight size={16}/></a></nav><a className="button button-dark header-cta" href="#contato">Consultar datas <ArrowUpRight size={16}/></a><button className="menu-toggle" type="button" aria-label={open ? "Fechar menu" : "Abrir menu"} aria-expanded={open} onClick={() => setOpen(!open)}>{open ? <X/> : <Menu/>}</button></div></header>;
}

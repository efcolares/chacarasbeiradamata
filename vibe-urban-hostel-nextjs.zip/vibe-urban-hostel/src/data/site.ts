export const site = {
  name: "Vibe Urban Hostel",
  tagline: "Sua próxima história começa aqui.",
  phoneDisplay: "(11) 3456-7890",
  phone: "1134567890",
  whatsapp: "5511987654321",
  address: "Av. Paulista, 1842 · Bela Vista, São Paulo - SP",
  addressNote: "Endereço demonstrativo — substitua pelos dados reais antes de publicar.",
  whatsappMessage: "Olá! Gostaria de consultar disponibilidade e valores no Vibe Urban Hostel.",
};
export const accommodations = [
  { title: "Cama cápsula", type: "Compartilhado · conforto individual", description: "Seu espaço privativo com cortina, luz de leitura, tomada e locker individual.", price: "R$ 75", image: "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=1200&q=85", alt: "Quarto com camas compartilhadas" },
  { title: "Suíte privativa", type: "Para dois · banheiro exclusivo", description: "Toda a privacidade de uma suíte com acesso à energia e aos espaços do hostel.", price: "R$ 190", image: "https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=1200&q=85", alt: "Suíte privativa com cama de casal" },
];
export const gallery = [
  { src: "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=1200&q=85", alt: "Quarto compartilhado" },
  { src: "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=1200&q=85", alt: "Área de convivência" },
  { src: "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=85", alt: "Espaço de trabalho" },
];
export const whatsappUrl = `https://wa.me/${site.whatsapp}?text=${encodeURIComponent(site.whatsappMessage)}`;
